"use strict";
var Fussball;
(function (Fussball) {
    class Moveable {
    }
    Fussball.Moveable = Moveable;
})(Fussball || (Fussball = {}));
//# sourceMappingURL=Moveable.js.map